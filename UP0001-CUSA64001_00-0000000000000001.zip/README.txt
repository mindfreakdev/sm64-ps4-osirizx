Super Mario 64 - PS4 Port
===========================
Source: https://github.com/OsirizX/sm64-port/tree/ps4
=======================================================

1. Transfer the /data folder to your PS4

/data/self/system/common/lib/libScePigletv2VSH.sprx

/data/self/system/common/lib/libSceShaccVSH.sprx

2. Install UP0001-CUSA64001_00-0000000000000001.pkg

3. Have fun!

Note:

Savedata is stored at /data/sm64_save_file.bin